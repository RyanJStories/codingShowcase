
public class Person {
	protected String name;
	protected String address;
	protected String phone;
	
	
	public Person()
	{
		this.name = "";
		this.address = "";
		this.phone = "";
	}
	
	public Person(String name, String add, String ph)
	{
		this.name = name;
		this.address = add;
		this.phone = ph;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
