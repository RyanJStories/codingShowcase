
public class Main {
	
	public static void main(String[] args) {
			
		Person[] cares = new Person[2];
		
		cares[0] = new Person("Greg", "4201 south 95th street","414-555-3454" ); 
		cares[1] = new Customer("Gregory", "4201 north 95th street","414-555-3456", "14A", true);
		
		Person personObject = cares[0];
		Customer customerObject = (Customer) cares[1];
		
		
		System.out.println("This is " + personObject.getName() +
				"\nTheir address is: " + personObject.getAddress() + 
				"\nTheir number is: " + personObject.getPhone());
		System.out.println();
		
		System.out.println("This is " + customerObject.getName() +
				"\nTheir address is: " + customerObject.getAddress() + 
				"\nTheir number is: " + customerObject.getPhone() +
				"\nTheir customer id is: " + customerObject.getCustomerNumber()+
				"\nT/F are they on the email list: " + customerObject.isMailingList());
		
		
		
	}
}
