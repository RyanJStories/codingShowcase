
public class Customer extends Person{
	
	private String customerNumber;
	private boolean mailingList;
	
	public Customer()
	{
		this.name = "";
		this.address = "";
		this.phone = "";
		this.customerNumber ="";
		this.mailingList= false;
	}
	public Customer(String name, String add, String ph, String custNum, boolean mL)
	{
		this.name = name;
		this.address = add;
		this.phone = ph;
		this.customerNumber = custNum;
		this.mailingList = mL;
	}
	public String getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	public boolean isMailingList() {
		return mailingList;
	}
	public void setMailingList(boolean mailingList) {
		this.mailingList = mailingList;
	}
}
