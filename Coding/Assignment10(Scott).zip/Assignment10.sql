-- 1. 
CREATE VIEW CustomerAddresses AS

SELECT
    c.CustomerID, 
    c.EmailAddress, 
    c.LastName, 
    c.FirstName,
    ba.Line1 AS BillLine1, 
    ba.Line2 AS BillLine2, 
    ba.City AS BillCity, 
    ba.State AS BillState, 
    ba.ZipCode AS BillZip, 
    sa.Line1 AS ShipLine1, 
    sa.Line2 AS ShipLine2, 
    sa.City AS ShipCity, 
    sa.State AS ShipState, 
    sa.ZipCode AS ShipZip 

FROM MyGuitarShop.dbo.Customers c 
JOIN MyGuitarShop.dbo.Addresses ba ON c.BillingAddressID  = ba.AddressID
JOIN MyGuitarShop.dbo.Addresses sa ON c.ShippingAddressID = sa.AddressID;

-- 2. 
SELECT CustomerID, LastName, FirstName, BillLine1 FROM CustomerAddresses;

-- 3. 
UPDATE  CustomerAddresses SET ShipLine1 = '1990 Westwood Blvd.' WHERE CustomerID = 8;

-- 4.
CREATE VIEW OrderItemProducts AS
SELECT 
    o.OrderID, 
    o.OrderDate, 
    o.TaxAmount, 
    o.ShipDate,
    p.ProductName, 
    li.ItemPrice, 
    li.DiscountAmount, 
    li.ItemPrice - li.DiscountAmount AS FinalPrice, 
    li.Quantity, 
    (li.ItemPrice - li.DiscountAmount) * li.Quantity AS ItemTotal       
FROM MyGuitarShop.dbo.Orders o
JOIN MyGuitarShop.dbo.OrderItems li ON o.OrderID = li.OrderID
JOIN MyGuitarShop.dbo.Products p ON li.ProductID = p.ProductID;

-- 5.  
CREATE VIEW ProductSummary AS
SELECT 
    ProductName, 
    COUNT(OrderID) AS OrderCount,
    SUM(ItemTotal) AS OrderTotal 
FROM OrderItemProducts 
GROUP BY ProductName;

-- 6.
SELECT TOP 5 ProductName, OrderTotal FROM ProductSummary ORDER BY OrderTotal DESC;

-- 7.
CREATE PROCEDURE GetOrderItems @OrderID int
AS

BEGIN
    SELECT * FROM OrderItemProducts WHERE OrderID = @OrderID;
END;
--8
EXEC GetOrderItems @OrderID = 2093;

