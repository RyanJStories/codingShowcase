package scottFinalExam;

import java.util.ArrayList;

import javax.sound.sampled.LineUnavailableException;


public class Controller {
	private View central = new View();
	private SoundUtils note = new SoundUtils();
	private ArrayList<StudentModel> students = new ArrayList();
	private int numOfStudents;
	
	public Controller()
	{
		try {
			note.playNote();
		} catch (LineUnavailableException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Welcome to the Student Score Calculator.");
		numOfStudents = central.askForStudents();
		for(int i=0; i<numOfStudents; i++)
		{
			students.add(createStudent());
		}
		for(int i=0; i<numOfStudents; i++)
		{
			students.get(i).setStudentId(central.askForID(i));
			students.get(i).setFirstName(central.askForFirstName(i));
			students.get(i).setLastName(central.askForLastName(i));
			students.get(i).setEmailAddress(central.askForAddress(i));
			students.get(i).setProjectScore(central.enterProjectScore(i));
			students.get(i).setExamScores(central.enterExamtScores(i));
			students.get(i).setAssignments(central.enterAssignmentScores(i));
			students.get(i).setFinalScore(students.get(i).calcFinalScore());
			students.get(i).setSFinalScore(getLetterGrade(students.get(i).calcFinalScore()));
			
		}
		System.out.println();
		System.out.println("Here are the final grades");
		System.out.println();
		System.out.print("Student ID/");
		System.out.print("First Name/");
		System.out.print("Last Name/");
		System.out.print("Email Add/");
		System.out.print("Score/");
		System.out.print("grade");
		for(int i=0; i<numOfStudents; i++)
		{
			System.out.println();
			System.out.println(students.get(i).toString());
		}
	}
	private String getLetterGrade(int calcFinalScore) {
		if(calcFinalScore>949)
		{
			return "A";
		} else if(calcFinalScore>899)
		{
			return "A-";
		}
		else if(calcFinalScore>849)
		{
			return "B+";
		}
		else if(calcFinalScore>799)
		{
			return "B";
		}
		else if(calcFinalScore>749)
		{
			return "B-";
		}
		else if(calcFinalScore>699)
		{
			return "C+";
		}
		else if(calcFinalScore>649)
		{
			return "C";
		}
		else if(calcFinalScore>599)
		{
			return "D";
		}
		else
		{
			return "U";
		}	
	}
	public StudentModel createStudent()
	{
		StudentModel student = new StudentModel();
		return student;
		
	}
}
