package scottFinalExam;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class View {
	Scanner names = new Scanner(System.in);
	Scanner scores = new Scanner(System.in);
		
	
	public int askForStudents() {
		int studentNums = 0;
		boolean input=true;
		while(input)
		{
			System.out.println("How many Students are you grading?");
			studentNums = scores.nextInt();
			input = false;
		
		}
		return studentNums;
	}


	public int askForID(int i) {
		int ID =0;
		boolean input=true;
		while(input)
		{
			
				System.out.println("Whats the ID of student number " + (i+1));
				ID= scores.nextInt();
				input = false;
			
		
		}
		return ID;
	}


	public String askForFirstName(int i) {
		String FName ="";
		boolean input=true;
		while(input)
		{
			
				System.out.println("Whats the First Name of student number " + (i+1));
				FName= names.nextLine();
				input = false;
			
			
		}
		return FName;
	}
	public String askForLastName(int i) {
		String LName ="";
		boolean input=true;
		while(input)
		{
			
				System.out.println("Whats the Last Name of student number " + (i+1));
				LName= names.nextLine();
				input = false;
		
		}
	
		return LName;
	}


	public String askForAddress(int i) {
		String Address ="";
		boolean input=true;
		while(input)
		{
			
				System.out.println("Whats the Email Address of student number " + (i+1));
				Address = names.nextLine();
				input = false;
			
		}
	
		return Address;
	}
	public int enterProjectScore(int i) {
		int Score =0;
		boolean checking = true;
		System.out.println("Whats the Project Score of student number " + (i+1));
		while(checking)
		{
			
			Score=scores.nextInt();
			
			if((-1 < Score && Score < 201) == true)
			{
				checking=false;
				
			}
			else
			{
				System.out.println("Enter a number between 0 and 200");
			}
		}
		return Score;
	
		
	}


	public ArrayList<Integer> enterExamtScores(int x) {
		ArrayList<Integer> scoress = new ArrayList();
		int currentScore;
		
		for(int i=0; i<2; i++)
		{
			boolean checking = true;
			System.out.println("Whats the Score of  Exam " + (i+1) + " for student number " + (x+1));
			
			currentScore = scores.nextInt();
			
			while(checking)
			{
				if((-1 < currentScore && currentScore < 101) == true)
				{
					scoress.add(currentScore);
					checking=false;
				}
				else
				{
					System.out.println("Enter a number between 0 and 100");
					System.out.println("Enter a different number");
					currentScore = scores.nextInt();
				}
			
			}
			
		}
		return scoress;
		
	}


	public ArrayList<Integer> enterAssignmentScores(int x) {
		ArrayList<Integer> assignments = new ArrayList();
		int currentScore;
	
		int i = 0;
		while( i<6)
		{
			boolean checking = true;
			System.out.println("Whats the Score of Assignment " + (i+1) + " for student number " + (x+1));
			System.out.println("Enter -99 to stop entering");
			
			currentScore = scores.nextInt();
			
			
			while(checking)
			{
				if((-1 < currentScore && currentScore < 101) == true)
				{
					assignments.add(currentScore);
					checking=false;
				}
				else if(currentScore == -99)
				{
					int leftOver = 6 - i;
					for(int j = 0; j<leftOver; j++)
					{
						assignments.add(0);
						checking=false;
						
					}
					i=6;
				}
				else
				{
					System.out.println("Enter a number between 0 and 100");
					System.out.println("Enter a different number");
					currentScore = scores.nextInt();
				}
			}
			i++;
			
		}
		return assignments;
	}
	
}
