package scottFinalExam;

import java.util.ArrayList;

public class StudentModel {
	private int studentId =0; 
	private String firstName = " ";
	private String lastName = " ";
	private String emailAddress = " ";
	private int ProjectScore = 0;
	private ArrayList<Integer> ExamScores = new ArrayList();
	private ArrayList<Integer> Assignments = new ArrayList();
	private int finalGrade =0;
	private String SfinalGrade = " ";
	
	
	
	public String toString()
	{
		String finals = (this.firstName + "/" + this.lastName + "/" +this.emailAddress + "/" + this.finalGrade+ "/"+ SfinalGrade );
		return finals;
		
	}


	public int getStudentId() {
		return studentId;
	}


	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmailAddress() {
		return emailAddress;
	}


	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}


	public int getProjectScore() {
		return ProjectScore;
	}


	public void setProjectScore(int projectScores) {
		ProjectScore = projectScores;
	}


	public ArrayList<Integer> getExamScores() {
		return ExamScores;
	}


	public void setExamScores(ArrayList<Integer> examScores) {
		ExamScores = examScores;
	}


	public ArrayList<Integer> getAssignments() {
		return Assignments;
	}


	public void setAssignments(ArrayList<Integer> assignments) {
		Assignments = assignments;
	}


	public int calcFinalScore() {
		int x = 0;
		x+=this.getProjectScore();
		System.out.println(x);
		for(int i=0; i<this.Assignments.size();i++)
		{
			x+= this.Assignments.get(i);
			
		}
		for(int j=0; j<this.ExamScores.size();j++)
		{
			x+= this.ExamScores.get(j);
			
		}
		return x;
	}
	public void setFinalScore(int i)
	{
		finalGrade = i;
	}
	public void setSFinalScore(String i)
	{
		SfinalGrade = i;
	}
}
