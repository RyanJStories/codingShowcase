﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scott_FarmerGame
{
    internal class Program
    {
        static void Main(string[] args)
        {
            FarmerUI billy = new FarmerUI();

            Info.DisplayInfo();
            billy.PlayGame();
        }
    }
}
