﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Scott_FarmerGame
{
    public class Info
    {
        public static void DisplayInfo()
        {
            Console.WriteLine("Welcome to the Fox, Chicken, and Grain game!");
            Console.WriteLine("To move an item, simply type 'farmer' then the name of the item (fox, chicken, or grain) and hit enter.\r\nIf you don't want to move anything, type 'nothing' and hit enter.");
        }
    }
}