﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static Farmer;

namespace Scott_FarmerGame
{
    public class FarmerUI
    {
        private Farmer farmer = new Farmer();
        bool broadcast = true;

        public void DisplayGameState()
        {
           
            DisplayNorthBank();
            Console.WriteLine("River:      " + (farmer.FarmerDirection == Direction.North ? ">>>>>" : "<<<<<"));
            DisplaySouthBank();
        }

        public void DisplayNorthBank()
        {
            Console.WriteLine("North Bank: " + farmer.printNorthBank());
            Console.WriteLine("-------------------------");
        }

        public void DisplaySouthBank()
        {
            Console.WriteLine("-------------------------");
            Console.WriteLine("South Bank: " + farmer.printSouthBank());
           
        }

        public void DisplayWelcome()
        {
           
            Console.WriteLine("Help the farmer safely transport his fox, chicken, and grain across the river.");
            Console.WriteLine("The chicken cannot be left alone with the grain or it will eat it.");
            Console.WriteLine("The fox cannot be left alone with the chicken or it will eat it.");
            Console.WriteLine("You can only transport one item at a time.\n");
        }

        public void Play()
        {
            
           
            DisplayGameState();
            PromptForMove();
           

        }

        public void PlayGame()
        {
            DisplayWelcome();
            Play();
          
        }

        public void PromptForMove()
        {
            Console.WriteLine("Write 'farmer' or 'exit'");
            string input = Console.ReadLine().ToLower();
            if (input == "exit")
            {
                Console.WriteLine("Exiting game...");
                return;
            }

        
            if (input != "nothing" && input != "exit" && input != "farmer")
            {
                Console.WriteLine("Invalid input, please try again.\n");
                Play();
                return;
            }

        
            if (input == "farmer")
            {
                Console.WriteLine("What would you like to move? (Type the item name or 'nothing' to skip): ");
                string item = Console.ReadLine().ToLower();
                if (item == "chicken" || item == "grain" || item == "fox")
                {
                    if(farmer.Move(item)==false)
                    {
                        return;
                    }
                    
                }
                else
                {
                    Console.WriteLine("Invalid Input");
                    PromptForMove();

                }
            }

            Play();
        }

    }
}

