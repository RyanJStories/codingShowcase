﻿using System;
using System.Collections.Generic;
using System.Text;

public class Farmer
{
    private Direction farmerDirection;
    private List<string> northBank;
    private List<string> southBank;

    public Farmer()
    {
        farmerDirection = Direction.North;
        northBank = new List<string> { "fox", "chicken", "grain" };
        southBank = new List<string>();
    }

    public Direction FarmerDirection
    {
        get => farmerDirection;
        set => farmerDirection = value;
    }

    public List<string> NorthBank
    {
        get => northBank;
    }
    public string printNorthBank()
    {
        string final;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i<northBank.Count; i++)
        {
            sb.Append(northBank[i] + ", ");
        }
        final = sb.ToString();
        return final;
    }

    public List<string> SouthBank
    {
        get => southBank;
    }
    public string printSouthBank()
    {
        string final = "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < southBank.Count; i++)
        {
            sb.Append(southBank[i] + ", ");
        }
        final = sb.ToString();
        return final;
    }

    public bool AnimalAteFood()
    {
        if ((northBank.Contains("chicken") && northBank.Contains("grain") && farmerDirection == Direction.South) ||
            (southBank.Contains("chicken") && southBank.Contains("grain") && farmerDirection == Direction.North) ||
            (northBank.Contains("fox") && northBank.Contains("chicken") && farmerDirection == Direction.South) ||
            (southBank.Contains("fox") && southBank.Contains("chicken") && farmerDirection == Direction.North))
        {
            return true;
        }
        return false;
    }

    public bool DetermineWin()
    {
        if (southBank.Contains("fox") && southBank.Contains("chicken") && southBank.Contains("grain"))
        {
            return true;
        }
        return false;
    }

    public bool Move(string item)
    {
        if (northBank.Contains(item) && farmerDirection == Direction.North)
        {
            northBank.Remove(item);
            southBank.Add(item);
            farmerDirection = Direction.South;
        }
        else if (southBank.Contains(item) && farmerDirection == Direction.South)
        {
            southBank.Remove(item);
            northBank.Add(item);
            farmerDirection = Direction.North;
        }
        else if(item == "nothing")
        {
            Console.WriteLine("Nothing moved");
        }

        if(AnimalAteFood())
        {
            Console.WriteLine("Uh oh! An animal just Feasted! You lost!");
            return false;
        }
        return true;
    }

    public enum Direction
    {
        North,
        South
    }
}
