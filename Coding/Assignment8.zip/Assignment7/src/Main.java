import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Main{
	
    Phonebook phonebookApp = new Phonebook();
    Phonebook phonebookApp2 = new Phonebook();
    Phonebook emptybook = new Phonebook();
    Phonebook randomPpl = new Phonebook();
    static PhonebookContainer container = new PhonebookContainer();
    public static void main(String[] args) {
        Phonebook phonebookApp = new Phonebook();
        Phonebook phonebookApp2 = new Phonebook();
        Phonebook emptybook = new Phonebook();
        Phonebook randomPpl = new Phonebook();
        container.addPhonebook(phonebookApp);
        container.addPhonebook(phonebookApp2);
        container.addPhonebook(emptybook);
        container.addPhonebook(randomPpl);
        
        
        File problemChild = new File("phonebook.dat");
        
        // Load phonebooks from file if it exists
        if (problemChild.exists()) {
        	  try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("phonebooks.dat"))) {
                  PhonebookContainer container = (PhonebookContainer) ois.readObject();
                  List<Phonebook> phonebooks = container.getPhonebooks();

                  phonebookApp = phonebooks.get(0);
                  phonebookApp2 = phonebooks.get(1);
                  emptybook = phonebooks.get(2);
                  randomPpl = phonebooks.get(3);
              } catch (IOException | ClassNotFoundException e) {
                  e.printStackTrace();
              }
        } else {
            fillPhonebooks(phonebookApp, phonebookApp2, randomPpl);
            
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(problemChild))) {
                PhonebookContainer container = new PhonebookContainer();
                container.addPhonebook(phonebookApp);
                container.addPhonebook(phonebookApp2);
                container.addPhonebook(emptybook);
                container.addPhonebook(randomPpl);
                oos.writeObject(container);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Phonebook all = new Phonebook(); // Initializes all phonebook reference

        Scanner scanner = new Scanner(System.in);

        boolean continueRunning = true;

        while (continueRunning) {
            System.out.println("Choose a phonebook:");
            System.out.println("1. Minecraft Phonebook");
            System.out.println("2. Celebrity Phonebook");
            System.out.println("3. Empty Phonebook");
            System.out.println("4. Random People Phonebook");
            System.out.println("5. Exit Application");

            int choice1;
            try {
                choice1 = scanner.nextInt();
                scanner.nextLine();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid choice (1/2/3/4/5).");
                scanner.nextLine(); // Consume the invalid input
                continue;
            }

            switch (choice1) {
                case 1:
                    all = phonebookApp;
                    break;
                case 2:
                    all = phonebookApp2;
                    break;
                case 3:
                    all = emptybook;
                    break;
                case 4:
                    all = randomPpl;
                    break;
                case 5:
                	scanner.close();
                	try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("phonebooks.dat"))) {
                        PhonebookContainer container = new PhonebookContainer();
                        container.addPhonebook(phonebookApp);
                        container.addPhonebook(phonebookApp2);
                        container.addPhonebook(emptybook);
                        container.addPhonebook(randomPpl);
                        oos.writeObject(container);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    continueRunning = false;
                    
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1, 2, 3, 4, or 5.");
            }

            if (continueRunning) {
                enterPhonebook(continueRunning, scanner, all);
            }
        }
    }

    	
    	
    	
    	
    	
    	
    	
    	
    	
    public static void enterPhonebook(boolean continueRunning, Scanner scanner, Phonebook all) {
        boolean inPhonebook = true;

        while (inPhonebook && continueRunning) {
            System.out.println("Options:");
            System.out.println("1. Add a new entry");
            System.out.println("2. Search for an entry");
            System.out.println("3. Print Phonebook");
            System.out.println("4. Choose new Phonebook");
            System.out.println("5. Edit entry");
            System.out.print("Enter your choice (1/2/3/4/5): ");

            int choice2;
            try {
                choice2 = scanner.nextInt();
                scanner.nextLine();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid choice (1/2/3/4/5).");
                scanner.nextLine(); // Consume the invalid input
                continue;
            }

            switch (choice2) {
                case 1:
                    all.enterNewPerson();
                    break;
                case 2:
                    String contactInfo = all.getContactInfo();
                    System.out.println(contactInfo);
                    break;
                case 3:
                    System.out.println("Phonebook Entries:");
                    all.printPhonebook();
                    break;
                case 4:
                    inPhonebook = false;
                    break;
                case 5:
                    System.out.println("Enter Number of Entry you want to Edit (include hashmarks)");
                    String keynum = scanner.nextLine();
                    all.editPhonebookEntry(keynum);
                    break;
                case 6:
                	System.out.println("Enter Number of Entry you want to Delete (include hashmarks)");
                	String keynum1 = scanner.nextLine();
                	all.deleteEntry(keynum1);
                	break;
                default:
                    System.out.println("Invalid choice. Please select 1, 2, 3, 4, or 5.");
            }
        }
    }
	
	



public static void fillPhonebooks(Phonebook phonebookApp, Phonebook phonebookApp2, Phonebook randomPpl)
{
	
	//filling the books
		String[] minecraftPhoneNumbers = {
			    "111-222-3333",
			    "222-333-4444",
			    "333-444-5555",
			    "444-555-6666",
			    "555-666-7777",
			    "666-777-8888",
			    "777-888-9999",
			    "888-999-0000",
			    "999-000-1111",
			    "000-111-2222"
			};

			String[] minecraftContactInfo = {
			    "Steve, 123 Main St, Minecraft City, MC, 12345",
			    "Alex, 456 Oak St, Minecraft Village, MC, 67890",
			    "Creeper, 789 Elm St, Creeper Town, MC, 13579",
			    "Zombie, 246 Dirt Rd, Zombie Village, MC, 80246",
			    "Enderman, 357 Stone Ave, Enderman Valley, MC, 24680",
			    "Skeleton, 555 Nether Rd, Skeleton Outpost, MC, 11111",
			    "Cave Spider, 789 Abandoned Mine, Webville, MC, 44444",
			    "Witch, 333 Swamp Dr, Witch's Hut, MC, 99999",
			    "Villager, 666 Village Square, Villagetown, MC, 77777",
			    "Herobrine, 123 Haunted Mansion, Mysteryville, MC, 54321"
			};
			String[] celebrityPhoneNumbers = {
				    "111-222-3333",
				    "222-333-4444",
				    "333-444-5555",
				    "444-555-6666",
				    "555-666-7777",
				    "666-777-8888",
				    "777-888-9999",
				    "888-999-0000",
				    "999-000-1111",
				    "000-111-2222"
				};

				String[] celebrityContactInfo = {
				    "Tom Hanks, 123 Hollywood Blvd, Los Angeles, CA, 90210",
				    "Angelina Jolie, 456 Movie Star Ln, Beverly Hills, CA, 90211",
				    "Brad Pitt, 789 Celebrity Ave, Malibu, CA, 90212",
				    "Meryl Streep, 246 Red Carpet Rd, Bel Air, CA, 90213",
				    "Leonardo DiCaprio, 357 Fame St, Hollywood Hills, CA, 90214",
				    "Jennifer Aniston, 555 Paparazzi Ave, Santa Monica, CA, 90215",
				    "Will Smith, 666 Blockbuster Dr, Calabasas, CA, 90216",
				    "Nicole Kidman, 888 Glamour Rd, Pacific Palisades, CA, 90217",
				    "George Clooney, 999 Stardom Ln, Venice Beach, CA, 90218",
				    "Oprah Winfrey, 000 Talkshow Dr, Malibu Beach, CA, 90219"
				};
				String[] randomPhoneNumbers = {
					    "111-222-3333",
					    "222-333-4444",
					    "333-444-5555",
					    "444-555-6666",
					    "555-666-7777",
					    "666-777-8888",
					    "777-888-9999",
					    "888-999-0000",
					    "999-000-1111",
					    "000-111-2222"
					};

					String[] randomContactInfo = {
					    "John Smith, 123 Elm St, Springfield, IL, 62701",
					    "Jane Doe, 456 Maple Ave, Raleigh, NC, 27601",
					    "Bob Johnson, 789 Oak Rd, Austin, TX, 73301",
					    "Mary Brown, 246 Pine Ln, Denver, CO, 80201",
					    "David Davis, 357 Cedar Dr, Seattle, WA, 98101",
					    "Lisa Wilson, 555 Birch Rd, Miami, FL, 33101",
					    "Michael Lee, 666 Cherry Blvd, Atlanta, GA, 30301",
					    "Sarah White, 777 Walnut Ave, Boston, MA, 02101",
					    "James Taylor, 888 Redwood St, Phoenix, AZ, 85001",
					    "Karen Anderson, 999 Sycamore Ct, Portland, OR, 97201"
					};
					
					
					phonebookApp.fillPhonebook(minecraftPhoneNumbers, minecraftContactInfo);	
					phonebookApp2.fillPhonebook(celebrityPhoneNumbers, celebrityContactInfo);
					randomPpl.fillPhonebook(randomPhoneNumbers, randomContactInfo);
				
}


}








