
import java.io.Serializable;
import java.util.Hashtable;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Phonebook implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String phoneNumber;
	private String contactInfo;
    transient private Scanner scanner = new Scanner(System.in);
    private Hashtable<String, String> phonebook;
    private boolean continueAdding = true;
    private boolean editing = true;
  
    public Phonebook() {
       phonebook = new Hashtable<>();
    }

    public void enterNewPerson() {
        while (continueAdding) {
            System.out.print("Enter phone number (include hashmarks): ");
            phoneNumber = scanner.nextLine();

            System.out.print("Enter name: ");
            String name = scanner.nextLine();

            System.out.print("Enter address: ");
            String address = scanner.nextLine();

            System.out.print("Enter city: ");
            String city = scanner.nextLine();

            System.out.print("Enter state: ");
            String state = scanner.nextLine();

            System.out.print("Enter ZIP code: ");
            String zip = scanner.nextLine();

            // Use a single string to store all the details
           contactInfo = name + ", " + address + ", " + city + ", " + state + ", " + zip;
            
            // Store the entry in the phonebook
            phonebook.put(phoneNumber, contactInfo);

            System.out.print("Do you want to add another entry? (yes/no): ");
            String response = scanner.nextLine();

            if (!response.equalsIgnoreCase("yes")) {
                continueAdding = false;
            }
        }
    }

    public void printPhonebook() {
        for (String phoneNumber : phonebook.keySet()) {
            System.out.println("Phone Number: " + phoneNumber);
            System.out.println("Contact Info: " + phonebook.get(phoneNumber));
        }
    }
    public String getContactInfo(){
    	
    	System.out.println("What is the Phone Number of the person you are looking up (include hashmarks):");
    	String pNumber = scanner.nextLine();
    	
    	if(phonebook.containsKey(pNumber))
    	{
    		return phonebook.get(pNumber);
    	}
    	else
    	{
		return "Person not in Phonebook";
    	}
    	
    }
    public void fillPhonebook( String[] phoneNumbers, String[] contactInfo) {
    	 if (phoneNumbers.length != contactInfo.length) {
    	        System.out.println("Error: Phone numbers and contact information array lengths don't match.");
    	        return;
    	    }

    	    for (int i = 0; i < phoneNumbers.length; i++) {
    	        phonebook.put(phoneNumbers[i], contactInfo[i]);
    	    }
    }
    public void editPhonebookEntry(String PN) {
    	String currentContactInfo = phonebook.get(PN);
     	String[] contactInfoParts = currentContactInfo.split(", ");

        while (editing) {
            System.out.println("Options:");
            System.out.println("1. Edit Name");
            System.out.println("2. Edit Address");
            System.out.println("3. Edit City");
            System.out.println("4. Edit State");
            System.out.println("5. Edit Zipcode");
            System.out.println("6. Save Phonebook Entry");
            System.out.println("7. Stop Editing");
            System.out.print("Enter your choice (1/2/3/4/5/6/7): ");

        	int choice;
        	try {
        	    choice = scanner.nextInt();
        	    scanner.nextLine();
        	} catch (InputMismatchException e) {
        	    System.out.println("Invalid input. Please enter a valid choice (1/2/3/4/5/6/7).");
        	    scanner.nextLine(); // Consume the invalid input
        	    continue; // Restart the loop
        	}

            if (phonebook.containsKey(PN)) {
               
                //taking the string and splitting it into an array of strings
              

                switch (choice) {
                    case 1:
                    	System.out.println("Old name: " + contactInfoParts[0]);
                        System.out.println("Enter new name: ");
                        String newName = scanner.nextLine();
                        contactInfoParts[0] = newName;
                        break;
                    case 2:
                    	System.out.println("Old address: " + contactInfoParts[1]);
                        System.out.println("Enter new address: ");
                        String newAddress = scanner.nextLine();
                        contactInfoParts[1] = newAddress;
                        break;
                    case 3:
                    	System.out.println("Old city: " + contactInfoParts[2]);
                        System.out.println("Enter new city: ");
                        String newCity = scanner.nextLine();
                        contactInfoParts[2] = newCity;
                        break;
                    case 4:
                    	System.out.println("Old state: " + contactInfoParts[3]);
                        System.out.println("Enter new state: ");
                        String newState = scanner.nextLine();
                        contactInfoParts[3] = newState;
                        break;
                    case 5:
                    	System.out.println("Old zipcode: " + contactInfoParts[4]);
                        System.out.println("Enter new zipcode: ");
                        String newZipcode = scanner.nextLine();
                        contactInfoParts[4] = newZipcode;
                        break;
                    case 6:
                    	String updatedContactInfo = String.join(", ", contactInfoParts);
                    	System.out.println("Current updates: " + updatedContactInfo );
                    	
                    	System.out.println("Are you sure you want to save? (yes/no)");
                    	String answer = scanner.nextLine();
                    		if(answer.equals("yes"))
                    		{
                    			   // Update the phonebook entry with the new contact info
                                phonebook.put(PN, updatedContactInfo);
                                System.out.println("PB.get:" + phonebook.get(PN));
                                System.out.println("UpdatedContinf" + updatedContactInfo);
                                System.out.println("Phonebook entry saved.");
                                currentContactInfo = updatedContactInfo; // Update the current contact info
                    		}
                    		else
                    		{
                    			System.out.println("Did not save");
                    		}
                        break;
                    case 7:
                        editing = false; 
                        System.out.println("Editing mode exited");
                        break;
                    default:
                        System.out.println("Invalid choice. Please select 1, 2, 3, 4, 5, 6, or 7.");
                }

            } else {
                System.out.println("Phone number not found in the phonebook.");
            }
        }
		
    }
    public void deleteEntry(String PN) {
    	if (phonebook.containsKey(PN)) {
    		System.out.println("You have selected " + phonebook.get(PN)+ ".");
    		System.out.println("Are you sure you want to delete? (yes/no)");
        	String answer = scanner.nextLine();
        		if(answer.equals("yes"))
        		{
        			
        		phonebook.remove(PN);
                   
        		}
        		else
        		{
        			System.out.println("Did not delete");
        		}
    	}
    }

	
	
        
    
}

