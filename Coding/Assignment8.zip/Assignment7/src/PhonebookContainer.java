import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PhonebookContainer implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	private List<Phonebook> phonebooks;

    public PhonebookContainer() {
        phonebooks = new ArrayList<>();
    }

    public void addPhonebook(Phonebook phonebook) {
        phonebooks.add(phonebook);
    }

    public List<Phonebook> getPhonebooks() {
        return phonebooks;
    }
}