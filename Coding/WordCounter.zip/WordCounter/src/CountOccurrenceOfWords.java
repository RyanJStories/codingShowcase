import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap; 
 
 	public class CountOccurrenceOfWords 
 	{
 		public static void main(String[] args) throws IOException
 		{
 			// Set text in a string (using a text file so it's not as messy)
 			
 			String text = readFile("C:\\Users\\ryanj\\eclipse-workspace\\WordCounter\\src\\input.txt");

 			
 			// Create a TreeMap to hold words as key and count as value
 			Map<String, Integer> map = new TreeMap<>();
 			
 			String[] words = text.split("[\\s+\\p{P}]");
 			
 			for (int i = 0; i < words.length; i++) 
 			{
 				String key = words[i].toLowerCase();

 				if (key.length() > 0) 
 				{
 					if (!map.containsKey(key)) 
 					{
 						map.put(key, 1);
 					}
 					else
 					{
 						int value = map.get(key);
 						value++;
 						map.put(key, value);
 					}
 				}
 			}
 		
 	// Display key and value for each entry
 		
 			for (Map.Entry<String, Integer> entry : map.entrySet())
 			{	
 	         System.out.println(entry.getKey() + ": " + entry.getValue()); //prints out the instances and the word that was used
 			}
 		}

		private static String readFile(String fileName) throws IOException //to turn my File into a string
		{
			  StringBuilder sb = new StringBuilder();
		        try (BufferedReader bruffer = new BufferedReader(new FileReader(fileName))) {
		            String line;
		            while ((line = bruffer.readLine()) != null) {
		                sb.append(line).append("\n");
		            }
		        }
		        return sb.toString();
		}
 	

 
 	}
 	
 	
 	
 	