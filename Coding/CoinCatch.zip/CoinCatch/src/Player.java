import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.lang.reflect.Array;

public class Player implements KeyListener {
private int radius;
private int x;
private int y;
private int gravity = 1;
private boolean isJump;
private boolean startCount = false;
private int jumptime = 0;
private boolean isOnGround = false;
public Rectangle player = new Rectangle((int)x, (int)y, radius*2, radius*2);
private int speed =1;
private boolean held = false;
private boolean isLanded = true;
private boolean canJump = true;
private int direction = 2;
	public Player(int x, int y, int radius) {
		// TODO Auto-generated constructor stub
		this.x = x;
		this.y = y;
		this.radius = radius;
		
		
	}

	public void draw(Graphics g) {
		// TODO Auto-generated method stub
		Color c = Color.red;
		g.setColor(c);
		g.fillOval((int)x, (int)y, radius*2, radius*2);
		player.setBounds((int)this.x, (int)this.y, radius*2, radius*2);
		
		
	}
	

	public void Gravity() {
		y += gravity;
		}
		

	public int GetX() {
		// TODO Auto-generated method stub
		return 0;
	}

	
	@Override
	public void keyTyped(KeyEvent e) {
		
		
	}



	@Override
	public void keyPressed(KeyEvent e) {
		
		if(e.getExtendedKeyCode()==32 || e.getExtendedKeyCode()==37 || e.getExtendedKeyCode()==39)
		{
		if(e.getExtendedKeyCode()==32)
		{
			if(canJump==true)
			{
			held = true;
			isJump = true;
			}
		}
		if(e.getExtendedKeyCode()==37)
		{
			direction = 1;
		}
		else if(e.getExtendedKeyCode()==39)
		{
			direction = 2;	
		}
		
		
		}
	
		
	}

	

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
	
	}

	public boolean isJump() {
		return isJump;
	}


	public boolean startCount() {
		// TODO Auto-generated method stub
		return startCount;
	}

	public void collide() {
		for(int i = 0; i < Arena.yett.size(); i++)
		{
			if(isJump() == false )
			{
			if(isOnGround && Arena.yett.get(i).getRect().intersects(player) ) 
			{
				
				this.y = Arena.yett.get(i).getY() - radius*2 + 1;
				gravity = 0;
				isLanded = true;
				canJump=true;
				
			}
			else
				if(Arena.yett.get(i).getRect().intersects(player))
				{
				isLanded=false;
				canJump=false;
				}
				}
				gravity=5;
				
			}
		}

	
	public int getSpeed() {
		// TODO Auto-generated method stub
		return speed;
	}

	public void setIsonGround(boolean b) {
		isOnGround = b;
		
	}

	public void increaseSpeed() {
		this.speed  +=1;
		
	}

	public void move() {
		if(direction==2)
		{
			this.x+=5;
		}
		else if(direction == 1)
		{
			this.x-=5;
		}
		else
		{
			this.x+=0;
		}
		if (isJump==true && canJump == true)
		{
			this.y-=35;
			jumptime+=1;
			
			if(jumptime>20)
			{
				jumptime=0;
				isJump=false;
				canJump=false;
			}
			
		}
		
	}

	public boolean checkForDeath(int h) {
		if(this.y>h)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public void resetPosition(int i, int j) {
		this.x=i;
		this.y=j;
		
	}

	public void setSpeed(int i) {
		this.speed = i;
		
	}
	
	
}
