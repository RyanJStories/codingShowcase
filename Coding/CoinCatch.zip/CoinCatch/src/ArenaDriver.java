import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Rectangle;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class ArenaDriver{ //to make the frame that houses the code
	//declare all jpanels that are wrapped around it.
	
	private int x;
	private int y;
	public static Arena graphingPanel = new Arena();
	public ArenaDriver()//to make it anonymous
	{
		 JFrame myFrame = new JFrame(); //outer framing
		
		//Graph panel object
		
		x =20;
		y = 20;
		//filler panels
		//top
		JPanel emptyTopPanel = new JPanel();
		emptyTopPanel.setPreferredSize(new Dimension(myFrame.getWidth(), y));
		emptyTopPanel.setBackground(Color.BLACK);
		//right
		JPanel emptyRightPanel = new JPanel();
		emptyRightPanel.setPreferredSize(new Dimension(x, myFrame.getHeight()));
		emptyRightPanel.setBackground(Color.BLACK);
		//left
		JPanel emptyLeftPanel = new JPanel();
		emptyLeftPanel.setPreferredSize(new Dimension(x, myFrame.getHeight()));
		emptyLeftPanel.setBackground(Color.BLACK);
		//bottom
		JPanel emptyBottomPanel = new JPanel();
		emptyBottomPanel.setPreferredSize(new Dimension(myFrame.getWidth(), y));
		emptyBottomPanel.setBackground(Color.BLACK);
		//add all components to frame
		myFrame.add(emptyTopPanel, BorderLayout.NORTH);
		myFrame.add(emptyLeftPanel, BorderLayout.WEST);
		myFrame.add(emptyRightPanel, BorderLayout.EAST);
		myFrame.add(emptyBottomPanel, BorderLayout.SOUTH);
		myFrame.add(graphingPanel, BorderLayout.CENTER);
		

		
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFrame.pack(); //encloses the frame around the main panel
		myFrame.setVisible(true);
		myFrame.setLocationRelativeTo(null); //stays in center of screen (sets the location)
		myFrame.setResizable(false);
		myFrame.setAlwaysOnTop(true);
		myFrame.setExtendedState(Frame.MAXIMIZED_BOTH);
		graphingPanel.update();
	
	}
	
	public static void main(String[] args) {
		new ArenaDriver();
		
	}
	
	public void switchFramesState()
	{
		//after declaration, constant call and add to x and y variables.
	}

}
	
