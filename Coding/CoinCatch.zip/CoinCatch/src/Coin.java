import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;




public class Coin {
	
	private int x;
	private int y;
	private final int radius=10;
	private final int height = 40;
	public boolean active=true;
	private Rectangle coin = new Rectangle((int)x, (int)y, radius*2, height);
	
	Coin(int x, int y)
	{	
		this.y=y;
		this.x=x;
		
	}
		
	public void draw(Graphics g) {
		// TODO Auto-generated method stub
	
		Color c = Color.yellow;
		if(Arena.player.player.intersects(this.coin)==false)
		{
		
		g.setColor(c);
		g.fillOval((int)x, (int)y, radius*2, height);
		this.coin.setBounds(this.x, this.y, radius*2, height);
			if(this.coin.getX()+this.coin.getWidth()<0)
			{
				Arena.level.deleteCoin(this);
			}
		}
		else
		{
				
			
			Arena.level.deleteCoinPlusSpeed(this);
			
			
			
		}
	}
			
		
	
	
	public void cScroll()
	{
		
		this.x-= Arena.player.getSpeed();

	
	}

}
