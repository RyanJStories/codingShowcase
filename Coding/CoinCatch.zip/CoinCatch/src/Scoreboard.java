import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class Scoreboard {
	Font stringFont = new Font( "SansSerif", Font.PLAIN, 50 );
	private int x = 0;
	public int frameCount = 0;
	private int frameWalls;
	Scoreboard()
	{
		
	}
	public void draw(Graphics g) {
		// TODO Auto-generated method stub
		Color c = Color.black;
		g.setColor(c);
		g.setFont(stringFont);
		g.drawString("Coins: " + x,  Arena.WHEN_IN_FOCUSED_WINDOW, 60);
		
		
		
		
		
	}
	public void setCoins(int x) {
		this.x = x;
		
	}
	public int getHighScore()
	{
		return x;
	}
	public void updateFrameCount(int i) {
		frameCount+=i;
		
	}
	public int getFrameWalls() {
		
		return frameWalls;
		
	}
	public void setFrameWalls(int x) {
		frameWalls = x;
		
	}
	public int getFrameCount() {
	
		return frameCount;
	}
	public void updateFrameWalls(int i) {
		frameWalls+=i;
		
	}
}
