import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JPanel;


public class Arena extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final int WIDTH = this.getWidth(); //all caps = constant
	private final int HEIGHT = this.getHeight();//size of the panel
	public static Player player = new Player(400, 525, 40);
	public static boolean start = false;
	private boolean ended = false;
	private boolean running = true;
	static Level level = new Level();
	Random rand = new Random();
	public Scoreboard score = new Scoreboard();
	public Startscreen startMenu= new Startscreen();
	


	
	
	
	
	public static ArrayList<Wall> yett = new ArrayList<Wall>();
	public static ArrayList<Coin> coinarr = new ArrayList<Coin>();
	

	
	

	//sets up walls
	public static Wall getWall(int x)
	{
		return yett.get(x);
	}
	
	
	//sets up the class and listeners
	public Arena()
	{
		this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		this.setBackground(Color.GRAY);
		this.addKeyListener(player);
		this.addMouseListener(startMenu);
		this.setFocusable(true);
		
		
	
	
	}
	
	//paint class
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		if(startMenu.isGone() == false)
		{
			startMenu.draw(g);

		
		}
		
		if(startMenu.isGone() == true)
		{
			start = false;
		for(int i = 0; i < yett.size(); i++)
		{
			
			yett.get(i).draw(g);
		}
		for(int i = 0; i < coinarr.size(); i++)
		{
			
			coinarr.get(i).draw(g);
		}
		
		player.draw(g);
		score.draw(g);
		score.setCoins(level.gottenCoins());
		}
		if (startMenu.getEnd()==true)
			{
			startMenu.draw(g);
			}
	}	
	


	//game loop
	
	public void update() 
	{	
	
		reset();
		

		while(running)
		{
			if(start)
			{
			
				reset();
				
			}
			
			repaint();
		
			//start of game
			if(startMenu.isGone() == true)
			{
				
				if(player.checkForDeath(this.getHeight()) !=true)
				{
					
					if(score.getFrameWalls() > 119-player.getSpeed())
					{
				
						level.createCoin();
						level.createWall();
						score.setFrameWalls(0);
				
					}
					player.Gravity();
					player.collide();
					player.move();
				
					scroll();
					score.updateFrameCount(1);
					score.updateFrameWalls(1);
			
					try 
					{
						Thread.sleep(1000/60);
					}catch (InterruptedException e)
					{
						e.printStackTrace();
					}	
				} 
				if(player.checkForDeath(this.getHeight()) ==true && startMenu.getEnd()==false)
				{
					startMenu.endScreen();
					startMenu.setHighScore(score.getHighScore());
					
				}
				
				
			}
		
			
			//end of game
			
		}
		

		
		
}





	private void scroll() {
		for(int i = 0; i < yett.size(); i++)
		{
			
			yett.get(i).wScroll();
		}
		for(int i = 0; i < coinarr.size(); i++)
		{
			
			coinarr.get(i).cScroll();
		}
		
	}


	private void reset() {
	
		if (startMenu.thisEnd == true)
		{
			running = false;
			
		}
		score.setCoins(0);
		player.resetPosition(400, 525);
		yett.removeAll(yett);
		coinarr.removeAll(coinarr);
		level.start();
		player.setSpeed(1);
		
		
		
	}


	public boolean isEnded() {
		return ended;
	}


	public void setEnded(boolean ended) {
		this.ended = ended;
	}


	
	





	



}



	






