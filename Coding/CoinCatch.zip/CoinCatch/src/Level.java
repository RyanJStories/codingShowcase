import java.awt.Rectangle;
import java.util.Random;
public class Level {
		//Wall(width, height, x, y)
	
	
	//floor
		Random rand = new Random();
		private int coinsGotten = 0;
		//not made yet


		
		
		 
		
		public Level()
		{
			
		}
	



			
		
		
		public Wall getWall(Wall one)
		{
			return one;
			
		}


		public void createWall() {
			int x=rand.nextInt(400, 700);//Height
			int y=rand.nextInt(50, 200);//Width
			int w =rand.nextInt(100, 1200); //Y-var
			boolean z;
			if(y>1100)
			{
				z = true;
			}
			else
			{
				z = false;
			}
			Wall newest = new Wall(x,y,2700, w, z);
			Arena.yett.add(newest);
		}
		
		public void deleteWall(Wall wall) {
			Arena.yett.remove(wall);
		}

		public void start() {
			Wall three = new Wall(3000, 500, 0, 1200, true);//floor
			Arena.yett.add(three);
			coinsGotten = 0;
		}


		public void createCoin() {
			
			Coin coin = new Coin(2600, rand.nextInt(300, 1000));
			Arena.coinarr.add(coin);
			
			
		}
		public void deleteCoin(Coin coin) {
			Arena.coinarr.remove(coin);
			
		}


		public void deleteCoinPlusSpeed(Coin coin) {
			deleteCoin(coin);
			Arena.player.increaseSpeed();
			coinsGotten+=1;
		
			
		}


		public int gottenCoins() {
			// TODO Auto-generated method stub
			return coinsGotten;
		}
		
		
		
		
		
		
		
		
	}







