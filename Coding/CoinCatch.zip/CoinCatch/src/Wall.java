import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Wall {
	public final int HEIGHT;
	public final int WIDTH;
	private int x;
	private int y;
	private boolean ground;
	private Color c = new Color(0);
	public Rectangle rect = new Rectangle(0, 0, 0, 0);
	Wall(int Height, int Width, int x, int y)
	{
		this.HEIGHT = Height;
		this.WIDTH = Width;
		this.x= x;
		
		this.ground = false;
		
		this.y = y;
	}
	Wall(int Height, int Width, int x, int y, boolean z)
	{
		this.HEIGHT = Height;
		this.WIDTH = Width;
		this.x= x;
		this.ground = z;
		
		this.y = y;
	}

	
	
	public void draw(Graphics g) {
		if(ground)
		{
		c = Color.green;
		}
		else
		{
		c = Color.MAGENTA;
		}
		g.setColor(c);
		g.fillRect(x, y, HEIGHT, WIDTH);
		rect.setBounds(this.x, this.y, this.HEIGHT, this.WIDTH);
			if(this.rect.intersects(Arena.player.player)) 
			{
				
				Arena.player.setIsonGround(true);
				
			}
			
			if(this.rect.getX()+this.rect.getWidth()<0)
			{
				Arena.level.deleteWall(this);
			}
		
	}
	public Rectangle getRect()
	{
		return this.rect;
		
	}

	public int getX() {
		// TODO Auto-generated method stub
		return x;
	}

	public int getWidth() {
		// TODO Auto-generated method stub
		return this.HEIGHT;
	}

	public int getY() {
		// TODO Auto-generated method stub
		return y;
	}


	public int getHeight() {
		return this.WIDTH;
	}
	
	public void wScroll()
	{
		
		this.x-= Arena.player.getSpeed();

	
	}

	
	
	

	

}
