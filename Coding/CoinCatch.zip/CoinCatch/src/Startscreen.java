import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Startscreen implements MouseListener {
	
	private boolean direct = false;
	private boolean isGone = false;
	private boolean endscreen = false;
	boolean thisEnd = false;
	Rectangle startButton = new Rectangle();
	Rectangle directions = new Rectangle();
	Rectangle backButton = new Rectangle();
	Rectangle resetButton = new Rectangle();
	Rectangle endButton = new Rectangle();
	private static int width = 200;
	private static int height = 80;
	Font stringFont = new Font( "SansSerif", Font.PLAIN, 50 );
	int mX = 0;
	int mY = 0;
	int highScore = 0;
	
	public boolean isGone() {
		// TODO Auto-generated method stub
		return isGone;
	}
	public void draw(Graphics g) {
		
		
		if(direct == false && isGone == false)
		{
		//start Button
		g.setColor(Color.RED);
		g.drawRect(ArenaDriver.graphingPanel.getWidth()/2-width/2, ArenaDriver.graphingPanel.getHeight()/2-height/2, width, height);
		g.fillRect(ArenaDriver.graphingPanel.getWidth()/2-width/2, ArenaDriver.graphingPanel.getHeight()/2-height/2, width, height);
		startButton.setBounds(ArenaDriver.graphingPanel.getWidth()/2-width/2, ArenaDriver.graphingPanel.getHeight()/2-height/2, width, height);
		
		// directions button
		g.drawRect(ArenaDriver.graphingPanel.getWidth()/2-(width+20)/2, ArenaDriver.graphingPanel.getHeight()/3-height/2, width+30, height);
		g.fillRect(ArenaDriver.graphingPanel.getWidth()/2-(width+20)/2, ArenaDriver.graphingPanel.getHeight()/3-height/2, width+30, height);
		directions.setBounds(ArenaDriver.graphingPanel.getWidth()/2-(width+20)/2, ArenaDriver.graphingPanel.getHeight()/3-height/2, width+30, height);
		
		//words
		g.setColor(Color.BLACK);
		g.setFont(stringFont);
		g.drawString("Start", ArenaDriver.graphingPanel.getWidth()/2-50 , ArenaDriver.graphingPanel.getHeight()/2+20);
		
		g.drawString("Directions", ArenaDriver.graphingPanel.getWidth()/2-110 , ArenaDriver.graphingPanel.getHeight()/3+20);
		g.setColor(Color.YELLOW);
		g.drawString("High Score: " + highScore, ArenaDriver.graphingPanel.getWidth()/2-110 , ArenaDriver.graphingPanel.getHeight()-200);
		
		g.setColor(Color.GREEN);
		g.drawString("Coin Catch!!", ArenaDriver.graphingPanel.getWidth()/2-110 , ArenaDriver.graphingPanel.getHeight()/5);
		}
		 if(endscreen== false && direct == true)
		{
			g.setColor(Color.BLACK);
			g.setFont(stringFont);
			g.drawString("Press space to jump", ArenaDriver.graphingPanel.getWidth()/2-50 , ArenaDriver.graphingPanel.getHeight()/5);
			g.drawString("Press > and < arrows for movement", ArenaDriver.graphingPanel.getWidth()/2-50 , ArenaDriver.graphingPanel.getHeight()/4);
			g.drawString("Collect coins to go faster", ArenaDriver.graphingPanel.getWidth()/2-50 , ArenaDriver.graphingPanel.getHeight()/3);
			g.drawString("Have fun running up the score!", ArenaDriver.graphingPanel.getWidth()/2-50 , ArenaDriver.graphingPanel.getHeight()/2);
			
			//back button
			g.setColor(Color.RED);
			g.drawRect(ArenaDriver.graphingPanel.getWidth()/3-width/2, ArenaDriver.graphingPanel.getHeight()/2-height/2, width, height);
			g.fillRect(ArenaDriver.graphingPanel.getWidth()/3-width/2, ArenaDriver.graphingPanel.getHeight()/2-height/2, width, height);
			backButton.setBounds(ArenaDriver.graphingPanel.getWidth()/3-width/2, ArenaDriver.graphingPanel.getHeight()/2-height/2, width, height);
			
			g.setColor(Color.BLACK);
			g.drawString("Menu", ArenaDriver.graphingPanel.getWidth()/3-width/3, ArenaDriver.graphingPanel.getHeight()/2+height/4);
		}

		 if(endscreen== true)
		{
			
			g.setColor(Color.RED);
			g.drawString("You Lost!", ArenaDriver.graphingPanel.getWidth()/2-50 , ArenaDriver.graphingPanel.getHeight()/3);
			
			g.setColor(Color.RED);
			g.drawRect(ArenaDriver.graphingPanel.getWidth()/3-width/2, ArenaDriver.graphingPanel.getHeight()/2-height/2, width, height);
			g.fillRect(ArenaDriver.graphingPanel.getWidth()/3-width/2, ArenaDriver.graphingPanel.getHeight()/2-height/2, width, height);
			resetButton.setBounds(ArenaDriver.graphingPanel.getWidth()/3-width/2, ArenaDriver.graphingPanel.getHeight()/2-height/2, width, height);
			

			g.setColor(Color.BLACK);
			g.drawString("Reset", ArenaDriver.graphingPanel.getWidth()/3-width/3, ArenaDriver.graphingPanel.getHeight()/2+height/4);
			
			
			g.setColor(Color.RED);
			g.drawRect(ArenaDriver.graphingPanel.getWidth()/2-width/2, ArenaDriver.graphingPanel.getHeight()/2-height/2, width, height);
			g.fillRect(ArenaDriver.graphingPanel.getWidth()/2-width/2, ArenaDriver.graphingPanel.getHeight()/2-height/2, width, height);
			endButton.setBounds(ArenaDriver.graphingPanel.getWidth()/2-width, ArenaDriver.graphingPanel.getHeight()/2-height/2, width, height);
			

			g.setColor(Color.BLACK);
			g.drawString("End", ArenaDriver.graphingPanel.getWidth()/2-width/3, ArenaDriver.graphingPanel.getHeight()/2+height/4);
			
	
			
		}
		
		
		if(startButton.intersects(mX, mY, 2, 2))
		{
			isGone = true;
			endscreen = false;
			direct = false;
			Arena.start = true;
			
			
		
		}
		if(directions.intersects(mX, mY, 2, 2))
		{
			direct = true;
		}
		if(backButton.intersects(mX, mY, 2, 2))
		{
			direct = false;
		}
		if(resetButton.intersects(mX, mY, 2, 2))
		{
			direct=false;
			endscreen = false;
			isGone = false;
			
		}
		if(endButton.intersects(mX, mY, 2, 2))
		{
		thisEnd = true;
			
		}
		
	}
	
	

	public void checkForClick(int x, int y) {
		this.mX = x;
		this.mY = y;
		
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
	
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		checkForClick(e.getX(),e.getY());
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		checkForClick(-1000,-10000);
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	public void endScreen() {
		if(isGone = true)
		{
		endscreen = true;
		direct = true;
		}
	}
	public boolean getEnd() {
		// TODO Auto-generated method stub
		return endscreen;
	}
	public void setHighScore(int x)
	{
		if(highScore < x)
		{
			highScore = x;
		}
	}
	
	
}
