

public class Employee {
	protected String employeeName = "";
	protected String employeeNumber = "";
	protected String hireDate= "";
	protected final String defaultEmployeeNum = "123-A";
	
	
	
	Employee(String x, String y, String z)
	{
		this.employeeName = x;
		this.employeeNumber = y;
		if(isValidEmpNum())
		{
			this.employeeNumber = y;
		}
		else
		{
			System.out.println("Set a different Employee Number, as the one inputted is invalid");
			System.out.println("Setting Employee Number to Default");
			this.employeeNumber = defaultEmployeeNum;
		}
		this.hireDate = z;
	}
	Employee()
	{
		
	}
	
	
	
	
	
	
	
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(String employeeNumber) {
		this.employeeNumber = employeeNumber;
		if(isValidEmpNum())
		{
			this.employeeNumber = employeeNumber;
		}
		else
		{
			System.out.println("Set a different Employee Number, as the one inputted is invalid");
			System.out.println("Setting Employee Number to Default");
			this.employeeNumber = defaultEmployeeNum;
		}
	}
	public String getHireDate() {
		return hireDate;
	}
	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}
	
	protected boolean isValidEmpNum()
	{
		boolean check = false;
		boolean check1 = false;
		boolean check2 = false;
		boolean check3 = false;
		boolean check4 = false;
		
		for(int i =0; i<this.employeeNumber.length(); i++)
		{
			if(Character.isDigit(this.employeeNumber.charAt(i))&& i<3)
			{
				check1 = true;
			}
			if(this.employeeNumber.charAt(i) == '-' && i == 3)
			{
				check2 = true;
			}
			if(Character.isAlphabetic(this.employeeNumber.charAt(i)) && i == 4)
			{
				if(this.employeeNumber.charAt(i)>='A' && this.employeeNumber.charAt(i)<= 'M')
				{
					check3 = true;
				}
			}
			if(this.employeeNumber.length() == 5)
			{
				check4 = true;
			}
		}
		if(check1 && check2 &&check3 && check4)
		{
			check = true;
		}

		return check;
		
	}
	public String toString()
	{
		return "Employee: " + this.employeeName + 
				"\nEmployee Number: "+ this.employeeNumber+
				"\nHire Date: " + this.hireDate;
		
	}
}
