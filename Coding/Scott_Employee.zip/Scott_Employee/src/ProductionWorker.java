
public class ProductionWorker extends Employee {

	private int Shift;
	private double hourlyPay;
	private final int DAY_SHIFT = 1;
	private final int NIGHT_SHIFT = 2;
	
	
	ProductionWorker(String x, String y, String z, int a, double b)
	{
		super(x, y, z);
		Shift = a;
		hourlyPay = b;
		
	}
	
	ProductionWorker()
	{
		
	}
	
	
	
	public int getShift() {
		return Shift;
	}

	public void setShift(int shift) {
		Shift = shift;
	}
	
	
	

	public double getHourlyPay() {
		return hourlyPay;
	}

	public void setHourlyPay(double hourlyPay) {
		this.hourlyPay = hourlyPay;
	}

	ProductionWorker(String x, String y, String z) {
		super(x, y, z);
	}
	private String DayorNight(int x)
	{
		if(x ==DAY_SHIFT)
		{
			return"Day Shift";
		}
		if(x == NIGHT_SHIFT)
		{
			return"Night Shift";
		}
		
		return "No valid Shift";
	}
	
	public String toString()
	{
		return "Employee: " + this.employeeName + 
				"\nEmployee Number: "+ this.employeeNumber+
				"\nHire Date: " + this.hireDate+
				"\nShift: " + DayorNight(getShift())+
				"\nPay Rate: " + hourlyPay;
		
	}
		
	

}
