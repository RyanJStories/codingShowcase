
public class Main {
	public static void main(String[] args) {
		
		Employee ryan = new Employee("Ryan", "456-G", "11/12");
		System.out.println(ryan.toString());
		
		System.out.println();
		
		ProductionWorker james = new ProductionWorker("James", "968-N", "12/11", 1, 10.35);
		
		System.out.println();
		System.out.println(james.toString());
		
		james.setEmployeeNumber("968-M");
		james.setShift(2);
		
		System.out.println();
		
		System.out.println(james.toString());
	}
}
