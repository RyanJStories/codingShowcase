package scott_GuessTheWord;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class UserInput {
	private String autoWord = "Default";
	private String guessedWord = " ";
	String[] possibilities = {"hello", "goodbye", "beat", "wonder", "excitment", "brother",
								"under", "determined", "jealous", "bad", "traditional", "planetary"};
	
	Random rando = new Random();
	private Scanner two = new Scanner(System.in);
	public boolean ongoing = true;
	int tries= 7;
	
	
	
	
	public void guessWord() {
		char[] charactersAuto = autoWord.toCharArray();
		System.out.println(" Guess the Word! It has " + charactersAuto.length + " letters");
		guessedWord = two.nextLine();
	}
	public void guessWord(int ult) {
		System.out.println("This word has "+ ult + " letters"  );
		System.out.println(" Guess the Word!");
		guessedWord = two.nextLine();
	}
	
	public void setAutoWord()
	{
		autoWord = possibilities[rando.nextInt(0,10)];
		
		
		
	}
	private void printLetter(char ult, boolean b)
	{
		if(b == true)
		{
			System.out.print(ult);
		
			
		}
		else
		{
			System.out.print("!");
		}
	}

	public void compareWords() {
		char[] charactersUser = guessedWord.toCharArray();
		char[] charactersAuto = autoWord.toCharArray();
		 ArrayList<Integer> correctPlaces = new ArrayList<Integer>();
	
		if(charactersUser.length == charactersAuto.length )
		{
		 if(!(guessedWord.equals(autoWord)))
		 {
			 for(int i=0; i<charactersAuto.length; i++)
			 {
			
				 if(charactersAuto[i] == charactersUser[i])
				 {
					 printLetter(charactersAuto[i], true);
				 }else
				 {
					 printLetter(charactersAuto[i], false);
				 }
			 }
			 System.out.println();
		 }else
		
		 {
			 System.out.println("You did it! The word was... " + autoWord);
			ongoing = false;
		 }
	
	}else
	{
		System.out.println("Choose a letter with " + charactersAuto.length + " letters" );
		tries-=1;
		System.out.println(" You have " + tries + " guesses left");
		if(tries<1)
		{
			ongoing = false;
		}else
		{
		guessWord( charactersAuto.length);
		compareWords();
		}
		
		
	}
		
		if(tries<1)
		{
			System.out.println("You lose!");
			ongoing = false;
		}
		else
		{
			System.out.println(" You have " + tries + " guesses left");
		}
	}
	
	public boolean getonGoing()
	{
		return ongoing;
	}
	public void resetTries()
	{
		tries = 0;
	}
}
