package scott_GuessTheWord;

import java.util.Scanner;

import javax.sound.sampled.LineUnavailableException;

public class Game {
	
	UserInput use = new UserInput();
	private boolean active = true;
	private boolean play;
	private Scanner one = new Scanner(System.in);
	private boolean inGame = false;
	SoundUtils box = new SoundUtils();
	
	public void start() {
		// TODO Auto-generated method stub
		Intro into = new Intro();
		into.directs();
		try {
			box.playNote();
		} catch (LineUnavailableException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while(active)
		{
			if(inGame == false)
			{
			startGame();
			
			}
			if(play==true)
			{
				inGame = true;
				
				use.guessWord();
				use.compareWords();
				if(use.getonGoing()==false)
				{
					play=false;
					startGame();
				}
				
			}else {
				
				active = false;
			}
			
			
			
		}
		
	}

	private void startGame() {
		System.out.println("Would you like to play? Yes/True - No/False");
		play = one.nextBoolean();
		use.setAutoWord();
		
	}

	public boolean isRunning()
	{
		return active;
		
	}
	public void setActive(boolean x)
	{
		active = x;
	}
}
