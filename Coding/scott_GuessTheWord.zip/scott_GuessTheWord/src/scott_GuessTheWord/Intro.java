package scott_GuessTheWord;

public class Intro {

	public void directs() {
		
		System.out.println("Directions: Select True to start playing, false to quit.");
		System.out.println("You have seven guesses to get the word");
		System.out.println("If you get the word right, you get ");
	}

}
