package scott_GuessTheWord;

public class WordGuesser {
	private static Game game = new Game();
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		game.start();
	}

}
