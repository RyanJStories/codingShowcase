﻿using Scott_MagicPCApp;

public class scott_MagicPCApp
{
   private static Boolean running = true;
   private static void Main(string[] args)
    {
        MagicPCUI ball = new MagicPCUI();
        while(running)
        {
            ball.Start();

            running = ball.WillContinue();
        }
    }
}