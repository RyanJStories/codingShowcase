﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Scott_MagicPCApp
{
    public class MagicPC
    {
        private Random rand = new Random();
        private string answer;
        public String GetUserAnswer(int x)
        {
            x = rand.Next(0, 8);

            switch (x)
            {
                case 0:
                    answer = "Yes";
                    break;
                case 1:
                    answer = "No";
                    break;
                case 2:
                    answer = "All signs point to yes";
                    break;
                case 3:
                    answer = "The answer is too cloudy, try again later";
                    break;
                case 4:
                    answer = "It's less than likely";
                    break;
                case 5:
                    answer = "Maybe";
                    break;
                case 6:
                    answer = "It's possible";
                    break;
                case 7:
                    answer = "You should be embarassed to ask me this...";
                    break;
                case 8:
                    answer = "You already know the answer to this...";
                    break;
            }
            return answer;
        }
    }
}