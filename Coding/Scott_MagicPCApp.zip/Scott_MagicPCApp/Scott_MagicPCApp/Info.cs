﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Scott_MagicPCApp
{
    public class Info
    {
        public void DisplayInfo()
        {
            Console.WriteLine("Ask a Yes or No question to receieve the answer you seek!");
        }
        public void DisplayYesNo()
        {
            Console.WriteLine("Type 'True' to continue,");
            Console.WriteLine("Type 'False' to cease,");
        }
    }
}