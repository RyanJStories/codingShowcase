﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;

namespace Scott_MagicPCApp
{
    public class MagicPCUI
    {
        String Quest;
        private int userMagic;
        private MagicPC answerMe = new MagicPC();
        Info info = new Info();
       

        public void GetUserQuestion()
        {
            Quest = Console.ReadLine();
            
        }

        public void RespondToQuestion()
        {
            Console.WriteLine("The answer to the Question '" + Quest + "' is...");
            Console.WriteLine(answerMe.GetUserAnswer(userMagic));
            Console.WriteLine("Want to ask again?");
            info.DisplayYesNo();
        }

        public void UserInstructions()
        {
            info.DisplayInfo();
        }
        public Boolean WillContinue()
        {
            Boolean trufal;
            trufal = Convert.ToBoolean(Console.ReadLine());
            if(trufal)
            {
                return trufal;
            }
            else
            {
                return trufal;
            }
        }

        public void Start()
        {
            UserInstructions();
            GetUserQuestion();
            RespondToQuestion();
        }
    }
}