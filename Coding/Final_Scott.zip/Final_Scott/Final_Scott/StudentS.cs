﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class StudentS
    {


        List<Student> theStudentList = new List<Student>();



        public string PopulateStudents(string path)
        {
        try
        {
            theStudentList.Clear();

            using (StreamReader reader = new StreamReader(path))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] data = line.Split(',');
                    int studentId = int.Parse(data[0]);
                    string firstName = data[1];
                    string lastName = data[2];

                    List<int> earnedPoints = new List<int>();
                    List<int> possiblePoints = new List<int>();

                    for (int i = 3; i < data.Length; i += 2)
                    {
                        int earned = int.Parse(data[i]);
                        int possible = int.Parse(data[i + 1]);
                        earnedPoints.Add(earned);
                        possiblePoints.Add(possible);
                    }

                    Student student = new Student(studentId.ToString(), firstName, lastName);
                    for (int i = 0; i < earnedPoints.Count; i++)
                    {
                        student.EnterGrade(earnedPoints[i], possiblePoints[i]);
                    }

                    student.CalGrade();
                    theStudentList.Add(student);
                }
            }

            return null; 
        }
        catch (FileNotFoundException)
        {
            return $"File '{path}' not found.";
        }
        catch (Exception ex)
        {
            return $"An error occurred: {ex.Message}";
        }
    }

        public int ListLength
        {
            get { return theStudentList.Count; }
        }

        public string StudentID(int index)
        {
            return theStudentList.ElementAt(index).ID;
        }

        public string StudentLastName(int index)
        {
            return theStudentList.ElementAt(index).NameLast;
        }

        public string StudentGrade(int index)
        {

            return theStudentList.ElementAt(index).LetterGrade;
        }

        public float StudentAverage(int index)
        {

            return theStudentList.ElementAt(index).Average;
        }

    }


