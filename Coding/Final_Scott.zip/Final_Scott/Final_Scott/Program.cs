﻿using System;

class Program
{
    static void Main()
    {
        GradesUI grades = new GradesUI();
        grades.MainMethod();
    }
}