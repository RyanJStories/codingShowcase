﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class GradesUI
    {
        StudentS myStudentS= new StudentS();

    public void MainMethod()
    {
       
        string filePath = "C:\\Users\\ryanj\\source\\repos\\Final_Scott\\Final_Scott\\grades.txt";

        string errorMessage = myStudentS.PopulateStudents(filePath);

        if (errorMessage == null)
        {
            DisplayInfo();
        }
        else
        {
            Console.WriteLine(errorMessage);
        }
    }

    void DisplayInfo()
        {
        Console.WriteLine("***************************************************************************");
        Console.WriteLine();
        Console.WriteLine("Name:              Ryan James Scott");
        Console.WriteLine("Course:            ITDEV-115");
        Console.WriteLine("Instructor:        Janese Christie");
        Console.WriteLine("Assignment:        Final Program");
        Console.WriteLine("Date:              5/15/2023");
        Console.WriteLine();
        Console.WriteLine("***************************************************************************");
        Console.WriteLine();
        Console.WriteLine();
        Console.WriteLine();
        Console.WriteLine();
        Console.WriteLine();
        Console.WriteLine();

        Console.WriteLine("Student id\tLast Name\tAverage  \tGrade");

            for (int index = 0; index < myStudentS.ListLength; index++)
            {

                Console.WriteLine(" {0} \t {1}    \t {2}    \t {3}", myStudentS.StudentID(index), myStudentS.StudentLastName(index), myStudentS.StudentAverage(index), myStudentS.StudentGrade(index));
            }
        Console.WriteLine();
        Console.WriteLine();
        Console.WriteLine();
        Console.WriteLine();
    }
          
    }

